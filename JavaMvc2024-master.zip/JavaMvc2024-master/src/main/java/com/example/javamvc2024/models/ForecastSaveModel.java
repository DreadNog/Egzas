package com.example.javamvc2024.models;

public class ForecastSaveModel {
    public String dateTime;
    public String city;
}
