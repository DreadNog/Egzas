package com.example.javamvc2024.models;

public class Coordinates{
    public double latitude;
    public double longitude;
}
