package com.example.javamvc2024.models;

import java.util.ArrayList;

public class IndexModel {
    public String city;
    public ArrayList<ForecastModel> forecasts;
}
