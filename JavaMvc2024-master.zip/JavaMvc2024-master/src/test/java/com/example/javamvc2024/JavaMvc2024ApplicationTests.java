package com.example.javamvc2024;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaMvc2024ApplicationTests {

    @Test
    void contextLoads() {
    }

}
